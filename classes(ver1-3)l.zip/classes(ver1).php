<?
class Human {
    public $weight;
    public $height = 170;
    public $name = 'Иван';
    public $lastName = 'Иванов';

    public function getFullName() {
        return "FullName: {$this->name} {$this->lastName}";
    }

    public function init($name, $lastName, $weight, $height) {
        $this->name = $name;
        $this->lastName = $lastName;
        $this->weight = $weight;
        $this->height = $height;
    }

    //private $name = 'Иван'; //Нельзя редактировать извне
    //private $lastName = 'Иваново'; //Нельзя редактировать извне
    protected  $gender = 'мужчина';
}

$human1 = new Human();
$human1->init('Павел', 'Сидоров', '90', '200');
//$weight = $human1->weight;
//$human1->weight = 80;
//$human1->childrens = 'yes';//У объекта можно динамически задавать новое свойство, но это считается дурным тоном.
//Лучше все свойства и модификаторы доступа объявлять заранее!
echo $human1->getFullName();
echo PHP_EOL;

$human2 = new Human();
$human2->init('Олег', 'Кошевой', '80', '180');
//$human2->weight = 90;
//$human2->height = 160;
//$human2->name = 'Алексей';
//$human2->lastName = 'Петров';
echo $human2->getFullName();;
echo PHP_EOL;

$human3 = new Human();
$human3->init('Назар', 'Тихомиров', '70', '165');
//$human3->weight = 65;
//$human3->height = 176;
//$human3->name = 'Максим';
//$human3->lastName = 'Перепилица';
echo $human3->getFullName();;
echo PHP_EOL;

//echo var_dump($weight);
//echo var_dump($human1);
//echo PHP_EOL;
//echo var_dump($human2);

?>