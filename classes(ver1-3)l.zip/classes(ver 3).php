<?
class Human {
    private $weight;
    private $height = 170;
    private $name = 'Иван';
    private $lastName = 'Иванов';

    public function getWeight() {
        return $this->weight;
    }

    public function getHeight() {
        return $this->height;
    }

    public function getFullName() {
        return "{$this->name} {$this->lastName}";
    }

    public function __construct($name, $lastName, $weight, $height) {
        if(!is_string($name)) {
            die('Неверное имя!');
        }
        $this->name = $name;
        $this->lastName = $lastName;
        $this->weight = $weight;
        $this->height = $height;
        Nation::increasePopulation();
    }

    public function __destruct()
    {
        Nation::decreasePopulation();
    }

    public function makeContract() {

    }

    public function makeTechnology() {

    }
}

class Nation {
    private $population = [];

    private static $allPopulation = 0;

    public static function increasePopulation($count = 1) {
        self::$allPopulation += $count;
    }

    public static function decreasePopulation($count = 1) {
        self::$allPopulation -= $count;
    }

    public static function getPopulation() {
        return self::$allPopulation;
    }

    public function add(Human $human) {
        $this->population[spl_object_id($human)] = $human;
    }

    public function remove(Human $human) {
        $objectId = spl_object_id($human);
        if(in_array($objectId, $this->population)) {
            unset($this->population[$objectId]);
        }
    }

    public function getFullInfo(Human $human) {
        return "Полное имя: {$human->getFullName()} Вес: {$human->getWeight()} Рост: {$human->getHeight()}" . PHP_EOL;
    }

    public function getFullInfoAboutAllPopulation() {
        foreach ($this->population as $itemOfPopulation) {
             echo $this->getFullInfo($itemOfPopulation) . PHP_EOL;
        }
    }
}

$human1 = new Human('Евгений', 'Сидоров', '90', '200');
$human2 = new Human('Олег', 'Кошевой', '80', '180');
$human3 = new Human('Назар', 'Тихомиров', '70', '165');

$nation = new Nation();
$nation->add($human1);
$nation->add($human2);
$nation->add($human3);

echo $nation->getFullInfoAboutAllPopulation();
?>